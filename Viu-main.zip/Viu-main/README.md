```
FIXED ERROR , WORK 18 July 2024
```

--------------------------------------

### Usage

1. Download ZIP <a href="https://codeload.github.com/agathasangkara/Viu/zip/refs/heads/main">here</a> and extract the ZIP 
2. Open CMD in folder Viu or Viu-main typing `python main.py`

--------------------------------------

### Please note

This script was made for educational purposes, I am not responsible for your actions using this script. This script was made for educational purposes.